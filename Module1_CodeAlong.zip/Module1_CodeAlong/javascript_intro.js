// console.log('Hello Miguel');

let city;
city = "Lisbon"; //String because it's wrapped up on quotes

city = 'Porto';

let name = 'Miguel';

let age = 25; //This is a variable with a number


console.log(city);
console.log(name);
console.log(age);

//let a;
//let b; => this is bad practive to have non-meaningful variable names

let myFavouriteCity;

const unitType = 'Celsius';

//  
//

// unitType = 'Fahrneit'; => this won't work - you cannot assign values to variables of type const

console.log(unitType);




